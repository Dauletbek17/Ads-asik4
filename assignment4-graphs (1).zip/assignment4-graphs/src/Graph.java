import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class Graph {
    // adjacency list, как в лекции: adj[i] - список соседей вершины i
    private ArrayList<ArrayList<Integer>> adj;
    private int numVertices;

    public Graph() {
        this.adj = new ArrayList<>();
        this.numVertices = 0;
    }

    // добавление вершины - просто добавляем новый пустой список соседей
    public void addVertex(Vertex v) {
        adj.add(new ArrayList<>());
        numVertices++;
    }

    // ненаправленное ребро - добавляем в оба списка
    public void addEdge(int from, int to) {
        if (from >= numVertices || to >= numVertices || from < 0 || to < 0) {
            System.out.println("Vertex doesn't exist!");
            return;
        }
        // чтобы не было дубликатов
        if (!adj.get(from).contains(to)) {
            adj.get(from).add(to);
        }
        if (!adj.get(to).contains(from)) {
            adj.get(to).add(from);
        }
    }

    public void printGraph() {
        for (int i = 0; i < numVertices; i++) {
            System.out.print("adj[" + i + "] = ");
            System.out.println(adj.get(i));
        }
    }

    // BFS - обход в ширину, использует очередь
    public void bfs(int start) {
        boolean[] visited = new boolean[numVertices];
        Queue<Integer> queue = new LinkedList<>();

        visited[start] = true;
        queue.add(start);

        System.out.print("BFS order: ");
        while (!queue.isEmpty()) {
            int current = queue.poll();
            System.out.print(current + " ");

            // проходим по всем соседям текущей вершины
            for (int neighbor : adj.get(current)) {
                if (!visited[neighbor]) {
                    visited[neighbor] = true;
                    queue.add(neighbor);
                }
            }
        }
        System.out.println();
    }

    // DFS - обход в глубину, использует стэк (итеративная версия)
    public void dfs(int start) {
        boolean[] visited = new boolean[numVertices];
        Stack<Integer> stack = new Stack<>();

        stack.push(start);

        System.out.print("DFS order: ");
        while (!stack.isEmpty()) {
            int current = stack.pop();

            if (!visited[current]) {
                visited[current] = true;
                System.out.print(current + " ");

                // добавляем соседей в стэк
                for (int neighbor : adj.get(current)) {
                    if (!visited[neighbor]) {
                        stack.push(neighbor);
                    }
                }
            }
        }
        System.out.println();
    }

    public int getNumVertices() {
        return numVertices;
    }
}
